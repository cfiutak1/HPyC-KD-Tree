To build and run native C++ version:
1. Do `make data` (this will take a few seconds)
2. Do `make`
3. Do `./program2 1 data/training/uniform/16777216_5.dat data/query/uniform/1_5_10.dat results.out`


To build and run Python version:
0. Do `make data`, if you haven't already
1. Do `make cython`
2. Do `python3 run_benchmarks.py`
