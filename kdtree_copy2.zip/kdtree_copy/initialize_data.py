import scripts.training_utils
import scripts.query_utils
import os

NUM_TRAINING_POINTS = (1 << 20)
NUM_DIMENSIONS = 5
DISTRIBUTION = 0 # Statistical distribution, leave as is

NUM_QUERIES = 1
NUM_NEIGHBORS = 10


os.system("mkdir -p data/training/uniform")
os.system("mkdir -p data/query/uniform")
scripts.training_utils.generate_training_file(NUM_TRAINING_POINTS, NUM_DIMENSIONS, DISTRIBUTION)
scripts.query_utils.generate_query_file(NUM_QUERIES, NUM_DIMENSIONS, NUM_NEIGHBORS, DISTRIBUTION)
